// ----------------------------------------------------------------------
// DAQ-Duino: Scilab side code. Make sure Arduino side is up and running.
// Author: Prof. Antonio Silveira (asilveira@ufpa.br)
//   Laboratory of Control and Systems, UFPA (lacos.ufpa.br)
//   Group of Control and Systems, UDESC (www.udesc.br)
// ----------------------------------------------------------------------

// Description: this is a very simple code to handle data acquisition essays
//              using Scilab and Arduino. The Arduino side code is required
//              in order to receive I/O requests from this Scilab side.
//              I/O range is 0V to 5V.

// Functions available:
//   DAQDUINO_START
//   DAQDUINO_END
//   DAQDUINO_READ
//   DAQDUINO_WRITE

// Use "help [name_function]" to get help!

// -----------------------------------------
// DAQDUINO_START(COMM) , Inform the comm port name String
//                        in use by Arduino, e.g. 'COM4'.

function []=daqduino_start(commport),
    global s;
    s = openserial(commport,'115200,n,8,1'); // Check you Arduino COMM port
    sleep(3e3);
    writeserial(s, '0.0' );
    sleep(2e3);
endfunction

////////////////////////////////////////////////////////////
// DAQDUINO_END  Ends the Scilab serial connection to the Arduino board
//               in use. It also sets the Arduino PWM channel in use to 0V.

function []=daqduino_end,
// Disconnect the serial link and put the PWM to zero
    global s;
    writeserial(s, '0.0' ); // Sends u(k)=0
    closeserial(s);
disp('DaqDuino ended.');
disp('');
disp('---------------------------------------------------');
disp('DAQ-Duino, 2013-2015.');
disp('Laboratory of Control and Systems (LACOS.ufpa.br).');
disp('Group of Control and Systems (GCS, udesc.br).');
disp('Author: Prof. Antonio Silveira (asilveira@ufpa.br).');
disp('---------------------------------------------------');
endfunction

////////////////////////////////////////////////////////////
// DAQDUINO_READ  Single-shot acquisition by A/D conversion of a single
//                sample from the analog input in use.

//   Example:
//     y=daqduino_read;

//         Stores to y a single sample from the analog channel in use. 
//         The range of the analog input is 0V to 5V.

function [y]=daqduino_read,
    global s;
    // READ FROM ARDUINO (Data is already in the Scilab buffer)
    y = strtod( readserial(s) );
         // Description: strings shared between Scilab and Arduino
         //              are converted, at both sides, to numbers (floats).
         if (y<0) then y=0; end
         //if (y>5) then y=5; end
endfunction

////////////////////////////////////////////////////////////////////////

// DAQDUINO_WRITE  Updates the DaqDuino PWM output in use.

//     daqduino_write(u,Ts) sets u Volts, where u range is 0V to 5V,
//     and Ts is the sampling time (a delay) given in seconds.

function []=daqduino_write(u,Ts),
    global s;
    
    if (u<0) then u=0; end
    if (u>5) then u=5; end
    
    // WRITE TO ARDUINO (it is going to update its PWM state and send back
                      // a past state of y(k) - causal system).
    writeserial(s, string( u ) ); // Sends u(k) as a string

    ///////////////////////////////////////////////////////
    sleep(Ts*1e3); // Sampling time interval
        // This is a very important part in order to guarantee
        // all the mathematical background on discrete-time systems.
endfunction

////////////////////////////////////////////////////////////////////////

// DAQDUINO_XCOS
function [y]=daqduino_xcos(input),
    global y;
    u=input(1);
    Ts=input(2);
    y=daqduino_read;
    daqduino_write(u,Ts);
endfunction

disp(['--------------------------------------';
      'DAQ-Duino: Scilab side code. Make sure';
      'Arduino side is up and running.       ';
      'Author: Prof. Antonio Silveira        ';
      '                     asilveira@ufpa.br';
      'Laboratory of Control and Systems,    ';
      '                  UFPA (lacos.ufpa.br)';
      'Group of Control and Systems,         ';
      '                  UDESC (www.udesc.br)';
      '                                      ';
      'Functions available:                  ';
      '    DAQDUINO_START                    ';
      '    DAQDUINO_END                      ';
      '    DAQDUINO_READ                     ';
      '    DAQDUINO_WRITE                    ']);
