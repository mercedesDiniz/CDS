// Example: parametric estimation using non recursive Least-Squares
clear; xdel(winsid()); clc;


Ts = 0.03; // Sampling time in seconds
tfinal = 2; // total time of the experiment
N = round( tfinal/Ts );  // total number of samples
t = 0:Ts:N*Ts-Ts; // time vector for plots

// Generation of an excitation input signal
u(1:2)=0; u(2:N)=2.5; // Volts


exec('loader.sce'); // load up DaqDuino functions
daqduino_start('/dev/ttyUSB0'); // start the DaqDuino connection

fig1=scf();
y(1)=0;
plot(t(1),u(1),'r'); plot(t(1),y(1),'b');

for k=2:N
    y(k) = daqduino_read();
    daqduino_write( u(k), Ts );
    plot(t(1:k),u(1:k),'r'); plot(t(1:k),y(1:k),'b');
end
daqduino_end;


// Non recursive Least-Squares estimator

PHI=[];
for k=3:N
    PHI = [PHI; [-y(k-1)  -y(k-2)  u(k-1) u(k-2) ] ];
end

P = inv( PHI'*PHI ) // Estimation error covariance matrix

Y = y(3:N); // Measurements vector
theta = P*PHI'*Y; // Estimated parameters vector
a1 = theta(1); a2 = theta(2); b0 = theta(3); b1 = theta(4);

ym(1:2)=0; // "validating" the estimated model
for k=3:N
    ym(k) = -a1*ym(k-1) -a2*ym(k-2) +b0*u(k-1) +b1*u(k-2);
end
plot(t,ym,'g'); legend('input','output','model output');
