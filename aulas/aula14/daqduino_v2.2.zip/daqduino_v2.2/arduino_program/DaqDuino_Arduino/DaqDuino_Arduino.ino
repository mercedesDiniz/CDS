// DAQ_Duino for Matlab/Scilab/Python (Arduino side code)
// Author: Antonio Silveira (asilveira@ufpa.br)
// Laboratory of Control and Systems, LACOS
// http://lacos.ufpa.br

// Description: this is a very simple code to handle data acquisition essays
//              using Matlab and Arduino. The Matlab side code is required
//		in order to send I/O requests to this Arduino side.

float u[1]={0.0};
float y[1]={0.0};
#define DA6 (6) // PWM Pin 6

void setup() {
  pinMode(DA6, OUTPUT);
  digitalWrite(DA6, LOW);
  Serial.begin(115200);
  Serial.setTimeout(5); // Maximum milisecs to wait for
                        // Serial.parseFloat to timeout
}

void loop() {
  if (Serial.available() > 0) {
    u[0] = Serial.parseFloat();
        if (u[0]<0) {u[0]=0;}
        if (u[0]>5) {u[0]=5;}
    u[0] = u[0]*(255/5.0);
    analogWrite(DA6,u[0]);
    
    y[0] = analogRead(A0)*(5/1023.0); // Pin A0 as Input
        if (y[0]<0) {y[0]=0;}
        if (y[0]>5) {y[0]=5;}
    Serial.println(y[0]);
  }
}
