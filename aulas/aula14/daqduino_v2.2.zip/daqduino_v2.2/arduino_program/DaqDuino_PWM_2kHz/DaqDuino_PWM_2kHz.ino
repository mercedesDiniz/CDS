// DAQ_Duino for Matlab/Scilab/Python (Arduino side code)
// Author: Antonio Silveira (asilveira@ufpa.br)
// Laboratory of Control and Systems, LACOS
// http://lacos.ufpa.br

// Description: this is a very simple code to handle data acquisition essays
//              using Matlab and Arduino. The Matlab side code is required
//		in order to send I/O requests to this Arduino side.

// REMARK: PWM 6 at 2kHz

float u[1]={0.0};
float y[1]={0.0};
#define DA6 (6) // PWM Pin 6

void setup() {
  pinMode(DA6, OUTPUT);
  digitalWrite(DA6, LOW);
  Serial.begin(115200);
  Serial.setTimeout(5); // Maximum milisecs to wait for
                        // Serial.parseFloat to timeout
  setPwmFrequency(DA6, 32); // base_freq/div = 62500Hz/32 = 1.9531 kHz = approx. 2kHz
}

void loop() {
  if (Serial.available() > 0) {
    u[0] = Serial.parseFloat();
        if (u[0]<0) {u[0]=0;}
        if (u[0]>5) {u[0]=5;}
    u[0] = u[0]*(255/5.0);
    analogWrite(DA6,u[0]);
    
    y[0] = analogRead(A0)*(5/1023.0); // Pin A0 as Input
        if (y[0]<0) {y[0]=0;}
        if (y[0]>5) {y[0]=5;}
    Serial.println(y[0]);
  }
}
// Arduino PWM Frequency function (from arduino.cc)

// Set pin 9's PWM frequency to 3906 Hz (31250/8 = 3906)
// Note that the base frequency for pins 3, 9, 10, and 11 is 31250 Hz
// setPwmFrequency(9, 8);

// Set pin 6's PWM frequency to 62500 Hz (62500/1 = 62500)
// Note that the base frequency for pins 5 and 6 is 62500 Hz
// setPwmFrequency(6, 1);

// Set pin 10's PWM frequency to 31 Hz (31250/1024 = 31)
// setPwmFrequency(10, 1024);

// Please keep in mind that changing the PWM frequency changes the Atmega's timers and disrupts the normal operation of many functions that rely on time (delay(), millis(), Servo library).

/**
 * Divides a given PWM pin frequency by a divisor.
 *
 * The resulting frequency is equal to the base frequency divided by
 * the given divisor:
 *   - Base frequencies:
 *      o The base frequency for pins 3, 9, 10, and 11 is 31250 Hz.
 *      o The base frequency for pins 5 and 6 is 62500 Hz.
 *   - Divisors:
 *      o The divisors available on pins 5, 6, 9 and 10 are: 1, 8, 64,
 *        256, and 1024.
 *      o The divisors available on pins 3 and 11 are: 1, 8, 32, 64,
 *        128, 256, and 1024.
 *
 * PWM frequencies are tied together in pairs of pins. If one in a
 * pair is changed, the other is also changed to match:
 *   - Pins 5 and 6 are paired on timer0
 *   - Pins 9 and 10 are paired on timer1
 *   - Pins 3 and 11 are paired on timer2
 *
 * Note that this function will have side effects on anything else
 * that uses timers:
 *   - Changes on pins 3, 5, 6, or 11 may cause the delay() and
 *     millis() functions to stop working. Other timing-related
 *     functions may also be affected.
 *   - Changes on pins 9 or 10 will cause the Servo library to function
 *     incorrectly.
 *
 * Thanks to macegr of the Arduino forums for his documentation of the
 * PWM frequency divisors. His post can be viewed at:
 *   http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1235060559/0#4
 */
void setPwmFrequency(int pin, int divisor) {
  byte mode;
  if(pin == 5 || pin == 6 || pin == 9 || pin == 10) {
    switch(divisor) {
      case 1: mode = 0x01; break;
      case 8: mode = 0x02; break;
      case 64: mode = 0x03; break;
      case 256: mode = 0x04; break;
      case 1024: mode = 0x05; break;
      default: return;
    }
    if(pin == 5 || pin == 6) {
      TCCR0B = TCCR0B & 0b11111000 | mode;
    } else {
      TCCR1B = TCCR1B & 0b11111000 | mode;
    }
  } else if(pin == 3 || pin == 11) {
    switch(divisor) {
      case 1: mode = 0x01; break;
      case 8: mode = 0x02; break;
      case 32: mode = 0x03; break;
      case 64: mode = 0x04; break;
      case 128: mode = 0x05; break;
      case 256: mode = 0x06; break;
      case 1024: mode = 0x7; break;
      default: return;
    }
    TCCR2B = TCCR2B & 0b11111000 | mode;
  }
}
